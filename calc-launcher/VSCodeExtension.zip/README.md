﻿# Calculator Launcher

A minimal Visual Studio Code extension that launches Windows Calculator.

## Installation

1. Download `calc-launcher-1.0.0.vsix` from this repository.
2. Open VS Code and press Ctrl+Shift+X.
3. Open the Extensions view's `...` menu.
4. Select Install from VSIX.
5. Select the downloaded package.

## Development

Press F5 in VS Code to launch the Extension Development Host.

## Command

Launch Calculator — launches Windows Calculator (`calc.exe`).
